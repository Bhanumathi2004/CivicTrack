package com.cms;

import java.io.*;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;
import model.Complaint;
import dao.ComplaintDAO;

public class ComplaintServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Complaint complaint = new Complaint();
        complaint.setUserId(Integer.parseInt(request.getParameter("userId")));
        complaint.setTitle(request.getParameter("title"));
        complaint.setDescription(request.getParameter("description"));
        complaint.setStatus("Pending");
        complaint.setDate(new Date());

        ComplaintDAO dao = new ComplaintDAO();
        boolean result = dao.fileComplaint(complaint);
        response.sendRedirect("viewcomplaints.jsp?success=" + result);
    }
}

