package com.cms;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import dao.ComplaintDAO;

public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int complaintId = Integer.parseInt(request.getParameter("id"));
        String status = request.getParameter("status");

        ComplaintDAO dao = new ComplaintDAO();
        dao.updateComplaintStatus(complaintId, status);
        response.sendRedirect("adminDashboard.jsp");
    }
}

