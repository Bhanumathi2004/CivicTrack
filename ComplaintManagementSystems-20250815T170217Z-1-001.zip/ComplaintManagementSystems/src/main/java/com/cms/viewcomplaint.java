package com.cms;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import util.DBUtil;

@MultipartConfig(fileSizeThreshold = 1024 * 1024, // 1 MB
                 maxFileSize = 1024 * 1024 * 5,    // 5 MB
                 maxRequestSize = 1024 * 1024 * 10) // 10 MB
public class viewcomplaint extends HttpServlet {

    // Handle form submission from addcomplaint.jsp
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Read form fields
        String type = request.getParameter("type");
        String description = request.getParameter("description");
        String location = request.getParameter("location");

        // For now, using static user_id (update with session later)
        int userId = 1;

        // Handle image upload
        Part filePart = request.getPart("image");
        String fileName = null;

        if (filePart != null && filePart.getSize() > 0) {
            fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName();
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();

            filePart.write(uploadPath + File.separator + fileName);
        }

        // Insert complaint into database
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO complaints (user_id, complaint_type, description, location, image, status, created_at) " +
                 "VALUES (?, ?, ?, ?, ?, 'Pending', NOW())"
             )) {

            stmt.setInt(1, userId);
            stmt.setString(2, type);
            stmt.setString(3, description);
            stmt.setString(4, location);
            stmt.setString(5, fileName); // Can be null

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Redirect to view complaints
        response.sendRedirect("viewcomplaint");
    }

    // Display all complaints in viewComplaints.jsp
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> complaintList = new ArrayList<>();

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT c.complaint_id, u.name, c.complaint_type, c.description, c.location, c.status, c.created_at, c.image " +
                 "FROM complaints c JOIN users u ON c.user_id = u.user_id")) {

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] complaint = new String[8];
                complaint[0] = rs.getString("complaint_id");
                complaint[1] = rs.getString("name");
                complaint[2] = rs.getString("complaint_type");
                complaint[3] = rs.getString("description");
                complaint[4] = rs.getString("location");
                complaint[5] = rs.getString("status");
                complaint[6] = rs.getString("created_at");
                complaint[7] = rs.getString("image"); // Image filename (optional)

                complaintList.add(complaint);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("complaints", complaintList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewComplaints.jsp");
        dispatcher.forward(request, response);
    }
}
