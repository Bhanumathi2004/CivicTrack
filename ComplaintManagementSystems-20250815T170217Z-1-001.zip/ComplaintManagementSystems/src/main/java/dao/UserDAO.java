package dao;

import java.sql.*;
import model.User;

public class UserDAO {

    // ✅ Update these with your actual DB details
    private final String jdbcURL = "jdbc:mysql://localhost:3306/your_database_name";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "root";

    // ✅ SQL to insert all fields into users table
    private static final String INSERT_USER_SQL =
        "INSERT INTO users (first_name, last_name, email, phone, address, city, state, pincode, password, role) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public boolean registerUser(User user) {
        boolean isRegistered = false;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the DB
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Prepare statement
            PreparedStatement stmt = conn.prepareStatement(INSERT_USER_SQL);
            stmt.setString(1, user.getFirstName());
            stmt.setString(2, user.getLastName());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getAddress());
            stmt.setString(6, user.getCity());
            stmt.setString(7, user.getState());
            stmt.setString(8, user.getPincode());
            stmt.setString(9, user.getPassword());  // You may hash this later
            stmt.setString(10, user.getRole());

            // Execute insertion
            int rows = stmt.executeUpdate();
            isRegistered = rows > 0;

            // Close resources
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();  // For debugging, log properly in production
        }

        return isRegistered;
    }
}
