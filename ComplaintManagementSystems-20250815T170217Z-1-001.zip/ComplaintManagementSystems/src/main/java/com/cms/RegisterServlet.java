package com.cms;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import model.User;
import dao.UserDAO;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        request.setCharacterEncoding("UTF-8");

        // Get all parameters from the form
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String pincode = request.getParameter("pincode");
        String password = request.getParameter("password");
        // You can optionally check confirmPassword here too

        // Create and populate User object
        User user = new User();
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        user.setCity(city);
        user.setState(state);
        user.setPincode(pincode);
        user.setPassword(password);
        user.setRole("user");

        // Save using DAO
        UserDAO dao = new UserDAO();
        boolean result = dao.registerUser(user);

        if (result) {
            response.sendRedirect("login.jsp");
        } else {
            response.sendRedirect("register.jsp?error=registrationFailed");
        }
    }
}
